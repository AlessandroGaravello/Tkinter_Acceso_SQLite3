import sqlite3

def crear_base_de_datos():
    # Conectar a la base de datos (creará el archivo si no existe)
    conn = sqlite3.connect('supermercado.sqlite')
    cursor = conn.cursor()

    # Crear tablas
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS categoria (
            idcategoria INTEGER PRIMARY KEY,
            categoria TEXT
        );
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS producto (
            idproducto INTEGER PRIMARY KEY,
            nombre TEXT,
            idcategoria INTEGER,
            medida TEXT,
            precio INTEGER,
            stock INTEGER,
            FOREIGN KEY (idcategoria) REFERENCES categoria(idcategoria)
        );
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS cliente (
            idcliente TEXT PRIMARY KEY,
            cia TEXT,
            contacto TEXT,
            cargo TEXT,
            direccion TEXT,
            ciudad TEXT,
            region TEXT,
            cp TEXT,
            pais TEXT,
            tlf TEXT,
            fax TEXT
        );
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS pedido (
            idpedido INTEGER PRIMARY KEY,
            idcliente TEXT,
            fechapedido TEXT,
            fechaentrega TEXT,
            FOREIGN KEY (idcliente) REFERENCES cliente(idcliente)
        );
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS detalle (
            idpedido INTEGER,
            idproducto INTEGER,
            precio REAL,
            unidades INTEGER,
            descuento REAL,
            FOREIGN KEY (idpedido) REFERENCES pedido(idpedido),
            FOREIGN KEY (idproducto) REFERENCES producto(idproducto)
        );
    ''')

    # Insertar datos de ejemplo en la tabla 'categoria'
    cursor.execute("INSERT INTO categoria (categoria) VALUES ('Frutas')")
    cursor.execute("INSERT INTO categoria (categoria) VALUES ('Verduras')")
    cursor.execute("INSERT INTO categoria (categoria) VALUES ('Lácteos')")

    # Insertar datos de ejemplo en la tabla 'producto'
    cursor.execute(
        "INSERT INTO producto (nombre, idcategoria, medida, precio, stock) VALUES ('Manzanas', 1, 'Kg', 2, 100)")
    cursor.execute(
        "INSERT INTO producto (nombre, idcategoria, medida, precio, stock) VALUES ('Zanahorias', 2, 'Kg', 1, 50)")
    cursor.execute(
        "INSERT INTO producto (nombre, idcategoria, medida, precio, stock) VALUES ('Leche', 3, 'Litro', 3, 200)")

    # Insertar datos de ejemplo en la tabla 'cliente'
    cursor.execute(
        "INSERT INTO cliente (idcliente, cia, contacto, cargo, direccion, ciudad, region, cp, pais, tlf, fax) VALUES ('C001', 'Supermercado XYZ', 'Juan Pérez', 'Gerente', 'Calle Principal 123', 'Ciudad A', 'Región 1', '12345', 'País A', '123-456-7890', '123-456-7891')")
    cursor.execute(
        "INSERT INTO cliente (idcliente, cia, contacto, cargo, direccion, ciudad, region, cp, pais, tlf, fax) VALUES ('C002', 'Tienda ABC', 'María Gómez', 'Dueña', 'Avenida Secundaria 456', 'Ciudad B', 'Región 2', '54321', 'País B', '987-654-3210', '987-654-3211')")

    # Insertar datos de ejemplo en la tabla 'pedido'
    cursor.execute(
        "INSERT INTO pedido (idcliente, fechapedido, fechaentrega) VALUES ('C001', '2023-12-08', '2023-12-15')")
    cursor.execute(
        "INSERT INTO pedido (idcliente, fechapedido, fechaentrega) VALUES ('C002', '2023-12-10', '2023-12-17')")

    # Insertar datos de ejemplo en la tabla 'detalle'
    cursor.execute("INSERT INTO detalle (idpedido, idproducto, precio, unidades, descuento) VALUES (1, 1, 2, 50, 0.1)")
    cursor.execute("INSERT INTO detalle (idpedido, idproducto, precio, unidades, descuento) VALUES (1, 2, 1, 30, 0.05)")
    cursor.execute("INSERT INTO detalle (idpedido, idproducto, precio, unidades, descuento) VALUES (2, 3, 3, 20, 0.2)")

    # Guardar cambios y cerrar la conexión
    conn.commit()
    conn.close()

if __name__ == "__main__":
    crear_base_de_datos()
