import sqlite3
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import os

class SupermercadoApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Supermercado ERP")
        self.conn = sqlite3.connect('supermercado.sqlite')
        self.cursor = self.conn.cursor()

        self.notebook = ttk.Notebook(root)

        # Crear pestañas para todas las tablas
        for table_name in ["cliente", "producto", "pedido"]:
            tab_frame = ttk.Frame(self.notebook)
            self.notebook.add(tab_frame, text=table_name.capitalize())
            self.crear_interfaz_tabla(table_name, tab_frame)

        self.notebook.pack(expand=1, fill="both")

        # Configurar el cierre de la aplicación
        root.protocol("WM_DELETE_WINDOW", self.cerrar_aplicacion)

    def cerrar_aplicacion(self):
        # Confirmar los cambios en la base de datos antes de cerrar la aplicación
        respuesta = messagebox.askokcancel("Guardar cambios", "¿Quieres guardar los cambios antes de salir?")
        if respuesta:
            self.conn.commit()
        self.conn.close()
        self.root.destroy()

    def crear_interfaz_tabla(self, table_name, frame):
        # Obtener nombres de columnas
        column_names = [desc[1] for desc in self.cursor.execute(f"PRAGMA table_info({table_name});")]

        # Crear árbol para mostrar datos
        tree = ttk.Treeview(frame, columns=column_names, show="headings")
        for col in column_names:
            tree.heading(col, text=col)
            tree.column(col, width=100)  # Ajusta el ancho de las columnas según sea necesario

        # Obtener datos de la tabla y cargar en el árbol
        data = self.ejecutar_consulta(f"SELECT * FROM {table_name};")
        for row in data:
            tree.insert("", "end", values=row)

        tree.pack(expand=1, fill="both")

        # Botones y elementos para añadir, actualizar, borrar registros, filtrar y ordenar
        btn_nuevo = ttk.Button(frame, text="Nuevo", command=lambda: self.ventana_nuevo(table_name, tree))
        btn_nuevo.pack(side="left", padx=10)

        btn_actualizar = ttk.Button(frame, text="Actualizar", command=lambda: self.ventana_actualizar(table_name, tree))
        btn_actualizar.pack(side="left", padx=10)

        btn_borrar = ttk.Button(frame, text="Borrar", command=lambda: self.borrar_registro(table_name, tree))
        btn_borrar.pack(side="left", padx=10)

        btn_exportar_excel = ttk.Button(frame, text="Exportar a Excel", command=lambda: self.exportar_a_excel(table_name))
        btn_exportar_excel.pack(side="left", padx=10)

        # Añadir botón de filtro y orden
        btn_filtro_orden = ttk.Button(frame, text="Filtro/Orden", command=lambda: self.crear_filtros_orden(table_name, tree))
        btn_filtro_orden.pack(side="left", padx=10)

        # Añadir botón para mostrar gráfico solo en la pestaña de 'producto'
        if table_name == "producto":
            btn_mostrar_grafico = ttk.Button(frame, text="Mostrar Gráfico", command=lambda: self.mostrar_grafico(table_name))

            btn_mostrar_grafico.pack(side="left", padx=10)

    def mostrar_grafico(self, table_name):
        # Obtener datos de la tabla
        data = self.ejecutar_consulta(f"SELECT nombre, stock FROM {table_name};")

        # Crear un DataFrame de pandas
        df = pd.DataFrame(data, columns=["Nombre", "Stock"])

        # Crear una ventana para seleccionar el tipo de gráfico
        ventana_tipo_grafico = tk.Toplevel(self.root)
        ventana_tipo_grafico.title("Seleccionar Tipo de Gráfico")

        # Variable para almacenar el tipo de gráfico seleccionado
        tipo_grafico_var = tk.StringVar()
        tipo_grafico_var.set("Barras")  # Valor predeterminado

        # Crear botones de opción para los tipos de gráficos
        opciones_tipos_graficos = ["Barras", "Pastel", "Dispersión"]
        for opcion in opciones_tipos_graficos:
            ttk.Radiobutton(ventana_tipo_grafico, text=opcion, variable=tipo_grafico_var, value=opcion).pack()

        # Botón para confirmar la selección y mostrar el gráfico
        btn_confirmar = ttk.Button(ventana_tipo_grafico, text="Mostrar Gráfico", command=lambda: self.mostrar_grafico_seleccionado(table_name, df, tipo_grafico_var.get(), ventana_tipo_grafico))
        btn_confirmar.pack()

    def mostrar_grafico_seleccionado(self, table_name, df, tipo_grafico, ventana_tipo_grafico):
        # Crear una figura y un subgráfico
        fig, ax = plt.subplots(figsize=(10, 5))

        if tipo_grafico == "Barras":
            # Gráfico de barras
            ax.bar(df['Nombre'], df['Stock'])
            ax.set_title("Gráfico de Barras")
            ax.set_xlabel("Nombre del Producto")
            ax.set_ylabel("Stock")
        elif tipo_grafico == "Pastel":
            # Gráfico de pastel
            fig, ax = plt.subplots(figsize=(8, 8))
            ax.pie(df['Stock'], labels=df['Nombre'], autopct='%1.1f%%')
            ax.set_title("Gráfico de Pastel")
        elif tipo_grafico == "Dispersión":
            # Gráfico de dispersión
            ax.scatter(df['Nombre'], df['Stock'])
            ax.set_title("Gráfico de Dispersión")
            ax.set_xlabel("Nombre del Producto")
            ax.set_ylabel("Stock")

        # Mostrar gráfico en una nueva ventana
        nueva_ventana = tk.Toplevel(self.root)
        nueva_ventana.title(f"Gráfico - {tipo_grafico}")

        canvas = FigureCanvasTkAgg(fig, master=nueva_ventana)
        canvas.get_tk_widget().pack()
        canvas.draw()

    def crear_filtros_orden(self, table_name, tree):
        ventana_filtros_orden = tk.Toplevel(self.root)
        ventana_filtros_orden.title(f"Filtros/Orden {table_name.capitalize()}")

        # Obtener nombres de columnas
        column_names = [desc[1] for desc in self.cursor.execute(f"PRAGMA table_info({table_name});")]

        # Crear opciones de filtro y orden
        filtro_label = ttk.Label(ventana_filtros_orden, text="Filtrar por:")
        filtro_label.grid(row=0, column=0, padx=5, pady=5)

        filtro_var = tk.StringVar(ventana_filtros_orden)
        filtro_combobox = ttk.Combobox(ventana_filtros_orden, textvariable=filtro_var, values=column_names, state="readonly")
        filtro_combobox.grid(row=0, column=1, padx=5, pady=5)
        filtro_combobox.set(column_names[0])

        orden_label = ttk.Label(ventana_filtros_orden, text="Ordenar por:")
        orden_label.grid(row=1, column=0, padx=5, pady=5)

        orden_var = tk.StringVar(ventana_filtros_orden)
        orden_combobox = ttk.Combobox(ventana_filtros_orden, textvariable=orden_var, values=["Ascendente", "Descendente"], state="readonly")
        orden_combobox.grid(row=1, column=1, padx=5, pady=5)
        orden_combobox.set("Ascendente")

        def aplicar_filtro_orden():
            columna_filtro = filtro_combobox.get()
            tipo_orden = "ASC" if orden_combobox.get() == "Ascendente" else "DESC"

            # Obtener datos actuales del árbol
            current_data = [(tree.item(item)['values'], item) for item in tree.get_children()]

            # Filtrar y ordenar los datos según las opciones seleccionadas
            filtered_sorted_data = sorted(current_data, key=lambda x: x[0][column_names.index(columna_filtro)], reverse=(tipo_orden == "DESC"))

            # Limpiar el árbol
            for item in tree.get_children():
                tree.delete(item)

            # Insertar los datos filtrados y ordenados en el árbol
            for values, item in filtered_sorted_data:
                tree.insert("", "end", values=values)

            messagebox.showinfo("Filtrar/Ordenar", f"Registros de {table_name.capitalize()} filtrados y ordenados exitosamente.")

        btn_aplicar = ttk.Button(ventana_filtros_orden, text="Aplicar", command=aplicar_filtro_orden)
        btn_aplicar.grid(row=2, columnspan=2, pady=10)

    def ventana_nuevo(self, table_name, tree):
        ventana_nuevo = tk.Toplevel(self.root)
        ventana_nuevo.title(f"Añadir nuevo {table_name.capitalize()}")

        # Obtener nombres de columnas
        column_names = [desc[1] for desc in self.cursor.execute(f"PRAGMA table_info({table_name});")]

        entry_widgets = {}

        for i, col in enumerate(column_names):
            ttk.Label(ventana_nuevo, text=f"{col.capitalize()}:").grid(row=i, column=0, padx=5, pady=5)
            entry_widgets[col] = ttk.Entry(ventana_nuevo)
            entry_widgets[col].grid(row=i, column=1, padx=5, pady=5)

        btn_guardar = ttk.Button(ventana_nuevo, text="Guardar", command=lambda: self.guardar_nuevo_registro(table_name, tree, entry_widgets))
        btn_guardar.grid(row=len(column_names), columnspan=2, pady=10)

    def guardar_nuevo_registro(self, table_name, tree, entry_widgets):
        # Obtener valores de los widgets de entrada
        values = [entry_widgets[col].get() for col in entry_widgets]

        # Insertar nuevo registro en la base de datos
        self.ejecutar_consulta(f"INSERT INTO {table_name} VALUES ({', '.join(['?']*len(entry_widgets))});", values)

        # Actualizar el árbol con el nuevo registro
        tree.insert("", "end", values=values)

        messagebox.showinfo("Nuevo", f"Nuevo registro de {table_name.capitalize()} añadido exitosamente.")
        self.conn.commit()  # Guardar cambios en la base de datos

    def ventana_actualizar(self, table_name, tree):
        # Obtener el item seleccionado en el árbol
        item_seleccionado = tree.selection()

        if not item_seleccionado:
            messagebox.showwarning("Actualizar", f"Selecciona un registro de {table_name.capitalize()} para actualizar.")
            return

        ventana_actualizar = tk.Toplevel(self.root)
        ventana_actualizar.title(f"Actualizar {table_name.capitalize()}")

        # Obtener nombres de columnas
        column_names = [desc[1] for desc in self.cursor.execute(f"PRAGMA table_info({table_name});")]

        # Obtener valores del registro seleccionado
        valores_registro = tree.item(item_seleccionado)['values']

        entry_widgets = {}

        for i, (col, valor) in enumerate(zip(column_names, valores_registro)):
            ttk.Label(ventana_actualizar, text=f"{col.capitalize()}:").grid(row=i, column=0, padx=5, pady=5)
            entry_widgets[col] = ttk.Entry(ventana_actualizar)
            entry_widgets[col].insert(0, valor)  # Mostrar valor actual en el widget de entrada
            entry_widgets[col].grid(row=i, column=1, padx=5, pady=5)

        btn_actualizar = ttk.Button(ventana_actualizar, text="Actualizar", command=lambda: self.actualizar_registro(table_name, tree, item_seleccionado, entry_widgets))
        btn_actualizar.grid(row=len(column_names), columnspan=2, pady=10)

    def actualizar_registro(self, table_name, tree, item_seleccionado, entry_widgets):
        # Obtener valores actualizados
        values = [entry_widgets[col].get() for col in entry_widgets]

        # Obtener el id del registro seleccionado
        id_registro = tree.item(item_seleccionado)['values'][0]

        # Actualizar el registro en la base de datos
        self.ejecutar_consulta(f"UPDATE {table_name} SET {', '.join([f'{col} = ?' for col in entry_widgets])} WHERE id{table_name} = ?;", values + [id_registro])

        # Actualizar el árbol con los datos actualizados
        tree.item(item_seleccionado, values=values)

        messagebox.showinfo("Actualizar", f"Registro de {table_name.capitalize()} actualizado exitosamente.")
        self.conn.commit()  # Guardar cambios en la base de datos

    def borrar_registro(self, table_name, tree):
        # Obtener el item seleccionado en el árbol
        item_seleccionado = tree.selection()

        if not item_seleccionado:
            messagebox.showwarning("Borrar", f"Selecciona un registro de {table_name.capitalize()} para borrar.")
            return

        respuesta = messagebox.askyesno("Borrar", f"¿Estás seguro de borrar el registro seleccionado de {table_name.capitalize()}?")
        if respuesta:
            # Obtener el id del registro seleccionado
            id_registro = tree.item(item_seleccionado)['values'][0]

            # Borrar el registro de la base de datos
            self.ejecutar_consulta(f"DELETE FROM {table_name} WHERE id{table_name} = ?;", [id_registro])

            # Borrar el item del árbol
            tree.delete(item_seleccionado)

            messagebox.showinfo("Borrar", f"Registro de {table_name.capitalize()} borrado exitosamente.")
            self.conn.commit()  # Guardar cambios en la base de datos

    def exportar_a_excel(self, table_name):
        # Obtener datos de la tabla
        data = self.ejecutar_consulta(f"SELECT * FROM {table_name};")

        # Crear un DataFrame de pandas
        df = pd.DataFrame(data, columns=[desc[1] for desc in self.cursor.description])

        # Obtener la ruta del archivo Excel en el propio proyecto
        current_directory = os.path.dirname(os.path.realpath(__file__))
        file_path = os.path.join(current_directory, f"{table_name}_export.xlsx")

        # Guardar el archivo Excel en la ruta especificada
        df.to_excel(file_path, index=False)
        messagebox.showinfo("Exportar a Excel", f"Datos de {table_name.capitalize()} exportados a: {file_path}")
        self.conn.commit()  # Guardar cambios en la base de datos

    def ejecutar_consulta(self, consulta, parametros=None):
        if parametros:
            self.cursor.execute(consulta, parametros)
        else:
            self.cursor.execute(consulta)
        return self.cursor.fetchall()

if __name__ == "__main__":
    root = tk.Tk()
    app = SupermercadoApp(root)
    root.mainloop()
